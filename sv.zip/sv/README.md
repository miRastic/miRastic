# Sieve-AI
> Sieve-AI: A Drug Discovery Assistant

## Features and Updates

* MultiProcessing (vs ASYNC vs Threading) for faster execution and processing with system with multiple processors
* [20220430] Added multiprocessing to docking
* This package has been tested on Ubuntu and should be working fine till required packages are available.

## List of Requirements

### OS
  * Ubuntu 20 LTS
  * Not tested on windows OS

### AutoDock VINA 1.2.3
  - Step 1: Navigate to `https://github.com/ccsb-scripps/AutoDock-Vina/releases/tag/v1.2.3`
  - Step 2: Download `vina_1.2.3_linux_x86_64` (for Linux) or `vina_1.2.3_windows_x86_64.exe` (for windows)
  - Step 3: Rename and move it to `bin` directory in ubuntu and suitable executable directory in windows. Alternatively  path as `vina` could be set using environment variables in windows and alias in ubuntu.

### ChimeraX

### Openbabel
  * STEP 1: `sudo apt-get install openbabel`

### Python
  * Installed through Conda Environment

## Installation of Required Python Packages

### Using Conda Environment Manager
  - Step 1: [Install conda as described here](https://docs.conda.io/projects/conda/en/latest/user-guide/install/index.html)
  - Step 2: Run `conda env create --file <path-to-yml>/sieveai.yml`
  - Step 3: `conda activate sieveai`

### Using PIP [Not working]
  - Step 1: `pip install -r sieveai.requirements.txt`

## Examples
### Commandline Operations
1. Basic example
  - Step 1: Create a `receptor` directory and put receptor PDB files there
  - Step 2: Create a `ligand` directory and put PDB|SDF files there
  - Step 3: Open terminal and change directory (using `cd` command) to navigate to the directory
  - Step 4: Copy paste the command `python /home/vishalkumarsahu/git-projects/sieve-ai/cli`

2. If having multiple directories [using `-b` flag to define base path(s)]
  - Step 1-3 are same for different directories
  - Step 4: `python /home/vishalkumarsahu/git-projects/sieve-ai/cli -b /home/vishalkumarsahu/Desktop/Test-Del/docking-test-2 /home/vishalkumarsahu/Desktop/Test-Del/demo-1`

3. Custom ligand and receptor directory names
  - Step 1-3 are same for different directories
  - Step 4: `python /home/vishalkumarsahu/git-projects/sieve-ai/cli -dr membrane-receptor-pdbs -dl fda-approved-drugs1`

4. Custom ligand and receptor directory paths
  - Step 1-3 are same for different directories
  - Step 4: `python /home/vishalkumarsahu/git-projects/sieve-ai/cli -r /home/vishalkumarsahu/Desktop/Test-Del/docking-test-2/receptor`
