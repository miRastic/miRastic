

python cli.py -db /home/vishalkumarsahu/Desktop/Test-Del/docking-test -dr rec -dl lig