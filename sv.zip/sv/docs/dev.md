# Commandline
* `python cli.py`

# Web
* Run flask server
* Compile CSS using `sass scss/style.scss css/style.css`

# Updates
* [20210610] Ligand preparation for autodock vina 1.1.2 using mgltools
* [20210610] Receptor preparation for autodock vina 1.1.2 using mgltools
* [20210610] Docking using autodock vina 1.1.2 using mgltools
* [20210610] Result processing using ChimeraX
* [20220216] Molecule processing using ADFR Tools, docking using AutoDock Vina 1.2.3
* [20220216] Added SQLite DB logging
* [20220412] Rewritten the utilitylib
* [20220412] Added MolConverter to split multimodel files
