# Version 1 [20220114]

## Required Installations

1. AutoDock VINA 1.2.3
  * Installation
    - Step 1: Download [Vina 1.2.3](https://github.com/ccsb-scripps/AutoDock-Vina/releases/tag/v1.2.3)
    - Step 2: Setup vina to be executable as `vina` from commandline
        - `sudo mv <download_path>/vina_1.2.3_linux_x86_64 /opt/autodock/vina`
        - `sudo mkdir /opt/autodock && sudo mv <download_path>/vina_1.2.3_linux_x86_64 /opt/autodock/vina`
        - Make Vina executable by executing `sudo chmod a+x /opt/autodock/vina`
        - `echo '# Add VINA Path' >> ~/.bashrc`
        - `echo 'export PATH=/opt/autodock:$PATH' >> ~/.bashrc`
  * Uninstallation
    - Before proceeding with the following commands please create a backup because these commands are powerful and would remove complete directly
    - `rm -r /opt/autodock`
    - Manually remove `export PATH="$PATH:/opt/autodock"` entries from your `~/.bashrc` file.
  
2. ADFR Tools
  * Installation
    - Step 1: Visit [ADFR Download Page](https://ccsb.scripps.edu/adfr/downloads/) and download `ADFRsuite 1.0 Linux 64 installer app`
    - Step 2: Make the downloaded file executable `sudo chmod a+x <download_path>/ADFRsuite_Linux-x86_64_1.0_install`
    - Step 3: Start Installation `sudo <download_path>/ADFRsuite_Linux-x86_64_1.0_install`, you can choose `/opt/autodock` to install ADFR tools 
    - Step 4: 
        - `echo '# Add ADFR Suite Path' >> ~/.bashrc`
        - `echo 'export PATH=/opt/autodock/adfr1rc/bin:$PATH' >> ~/.bashrc` assuming ADFR tools have been installed in `/opt/autodock` directory

3. ChimeraX 1.2
  * 

4. Installing FreeSASA
  * Follow instructions at http://freesasa.github.io/

  * Download https://freesasa.github.io/freesasa-2.0.3.tar.gz and extract
  * ```sh
./configure
make
sudo make install
freesasa -h
```

4. Create Conda Environment
  - `conda env create --file docs/requirements/conda.sieve-ai.yml`
  - `pip install -r docs/requirements/pip.sieve-ai.txt`