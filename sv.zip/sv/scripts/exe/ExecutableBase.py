from scripts.utilitylib.UtilityManager import UtilityManager

class ExecutableBase():
  def __init__(self, *args, **kwargs):
    if not kwargs.get("utility") or not hasattr(self, "utility"):
          # This will add db in first project dir only
      kwargs["db_path"] = f"{kwargs.get('path_base')[0]}/sieve-ai.db"
      _utility = UtilityManager(**kwargs)
      _utility.db_connect()
      kwargs['utility'] = _utility

    self.__update_attr(*args, **kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults =  {}

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]
