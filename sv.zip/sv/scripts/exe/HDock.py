"""
To handle docking using HDock Server
"""

import os as OS
import requests as REQUESTS

# from scripts.helper import helper as HELP
from scripts.exe.ExecutableBase import ExecutableBase

class HDock(ExecutableBase):
  def __init__(self, *args, **kwargs):
    super(HDock, self).__init__(**kwargs)
    default_dir = OS.path.expanduser("~/Desktop")
    default_dir = self.utility.validate_dir(f"{default_dir}{OS.sep}HDockDir")
    self.email = "ctrlcolab@gmail.com"
    self.session = REQUESTS.Session()
    self.session.headers.update({'Referer': "http://hdock.phys.hust.edu.cn"})
    self.session.headers.update({'Origin': "http://hdock.phys.hust.edu.cn"})
    self.session.headers.update({"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"})
    self.session.headers.update({'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"})

    self.process_dir = kwargs.get("process_dir", default_dir)

  def log_table(self, directory = None, content = None, file_name = "hdock--docking-upload.log"):
    if not directory:
      return None
    self.utility.write(f"{directory}{OS.sep}{file_name}", content, True)

  def submit(self, rec_file_path, lig_file_path, base_dir):
    submit_url = "http://hdock.phys.hust.edu.cn/runhdock.php"

    lig_file_name = self.utility.file_name(lig_file_path)
    rec_file_name = self.utility.file_name(rec_file_path)

    project_title = f"{rec_file_name}--{lig_file_name}"
    complex_dir = f"{self.process_dir}{OS.sep}{base_dir}{OS.sep}{project_title}"

    if self.utility.check_path(complex_dir):
      # Don't submit again 
      self.utility.log_info(f"Already Submitted {project_title}.")
      return None
    else:
      self.utility.log_info(f"New Submission of {project_title}.")
      self.utility.validate_dir(complex_dir)

    files = {
      "pdbfile1": open(rec_file_path, 'rb'),
      "pdbfile2": open(lig_file_path, 'rb')
    }

    """
      # Fields
      "pdbfile1": "", # [object File]
      "pdbid1": "", # 
      "fastaseq1": "", # 
      "fastafile1": "", # [object File]
      "pdbfile2": "", # [object File]
      "pdbid2": "", # 
      "fastaseq2": "", # 
      "fastafile2": "", # [object File]
      "symmetry": "", # 
      "saxsfile": "", # [object File]
      "sitenum1": "", # 
      "sitefile1": "", # [object File]
      "sitenum2": "", # 
      "sitefile2": "", # [object File]
      "restrnum": "", # 
      "restrfile": "", # [object File]
      "email": "", # ctrlcolab@gmail.com
      "jobname": "", # iRAlpha-Th1001
    """
    form_values = {
      "pdbid1": "", # 
      "fastaseq1": "", # 
      "fastafile1": "", # [object File]
      "pdbid2": "", # 
      "fastaseq2": "", # 
      "fastafile2": "", # [object File]
      "symmetry": "", # 
      "saxsfile": "", # [object File]
      "sitenum1": "", # 
      "sitefile1": "", # [object File]
      "sitenum2": "", # 
      "sitefile2": "", # [object File]
      "restrnum": "", # 
      "restrfile": "", # [object File]
      "email": self.email, # 
      "jobname": str(project_title), # iRAlpha-Th1001
    }

    response = self.session.post(submit_url, data=form_values, files=files)
    response_url = response.url
    if response.history:
      print("Request was redirected")
    else:
      self.log_file(f"Request wasn't redirected.")

    self.log_table(project_title, response_url)

    process_html = ""
    with open(f"{complex_dir}/{project_title}.html","w+", encoding="utf-8") as f:
      process_html = response.text
      f.write(process_html)

    # Precautionary 30s pause
    self.utility.time_pause(32)

    self.utility.log_info(f"Completing Submission of {project_title}.")
    return True