"""
"""
import os as OS
import requests as REQUESTS

import pandas as PD

from scripts.exe.ExecutableBase import ExecutableBase

class PatchDock(ExecutableBase):
  def __init__(self, *args, **kwargs):
    super(PatchDock, self).__init__(**kwargs)
    default_dir = OS.path.expanduser("~/Desktop")
    default_dir = self.utility.validate_dir(f"{default_dir}{OS.sep}PatchDockDir")
    self.email = "ctrlcolab@gmail.com"

    self.session = REQUESTS.Session()
    self.session.headers.update({'Referer': "https://bioinfo3d.cs.tau.ac.il/PatchDock/php.php"})
    self.session.headers.update({'Origin': "https://bioinfo3d.cs.tau.ac.il/PatchDock/php.php"})
    self.session.headers.update({"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"})
    self.session.headers.update({'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"})

    self.process_dir = kwargs.get("process_dir", default_dir)

  def __parse_res_score_line(self, line):
    records = str(line).split("|")
    records = [r.strip() for r in records]
    return records

  def parse_res_file(self, patchdock_score_file):
    pd_score_res = []
    with open(patchdock_score_file, "r") as pds:
        pd_score_res = pds.readlines()

    score_table_data = []
    score_table_headers = []
    score_start_flag = False
    for res_line in pd_score_res:
        if score_start_flag:
            score_recs = self.__parse_res_score_line(res_line)
            score_table_data.append(score_recs)
        if not score_start_flag and "#" in res_line:
            score_table_headers = self.__parse_res_score_line(res_line)
            score_table_headers[0] = "model_id"
            score_start_flag = True

    score_table = PD.DataFrame.from_records(score_table_data, columns=score_table_headers)
    # # Keep Only 10 Records
    # score_table = score_table.head(10)
    score_table.rename(columns={"#": "model_id"})
    return score_table

  def log_table(self, directory = None, content = None, file_name = "patchdock--docking-upload.log"):
    if not directory:
      return None
    self.utility.write(f"{directory}{OS.sep}{file_name}", content, True)

  def submit(self, rec_file_path, lig_file_path, base_dir):
    submit_url = "https://bioinfo3d.cs.tau.ac.il/PatchDock/bin/htmlInvokePatchDock.pl"

    lig_file_name = self.utility.file_name(lig_file_path)
    rec_file_name = self.utility.file_name(rec_file_path)

    project_title = f"{rec_file_name}--{lig_file_name}"
    complex_dir = f"{self.process_dir}{OS.sep}{base_dir}{OS.sep}{project_title}"

    if self.utility.check_path(complex_dir):
      # Don't submit again 
      self.utility.log_info(f"Already Submitted {project_title}.")
      return None
    else:
      self.utility.log_info(f"New Submission of {project_title}.")
      self.utility.validate_dir(complex_dir)

    files = {
              "recfile": open(rec_file_path, 'rb'),
              "ligfile": open(lig_file_path, 'rb')
            }

    form_values = {
      "receptor": "",
      "ligand": "",
      "email": self.email,
      "rmsd": "4.0",
      "moltype": "Default",
      "recsitefile": "",
      "ligsitefile": "",
      "distconstraintsfile": "",
    }

    response = self.session.post(submit_url, data=form_values, files=files)
    response_url = response.url
    if response.history:
      print("Request was redirected")
    else:
      self.log_file(f"Request wasn't redirected.")

    self.log_table(project_title, response_url)

    process_html = ""
    with open(f"{complex_dir}/{project_title}.html","w+", encoding="utf-8") as f:
      process_html = response.text
      f.write(process_html)

    # Precautionary 30s pause
    self.utility.time_pause(32)

    self.utility.log_info(f"Completing Submission of {project_title}.")
    return True

  def download_results(result_url, docking_dir):
    raise Exception("Not implemented yet.")
    # ZIP Download URL
    # {patchdock_url}/bin/zipAndDownload.pl?solutionsNum=10&id=iRAlpha.pdb_Th1014.pdb_38_54_10_8_10_121&Submit=GO
    patchdock_url = "http://bioinfo3d.cs.tau.ac.il/PatchDock"

    res_2 = str(result_url).replace(f"{patchdock_url}/runs/", "")
    jobid = res_2.strip("/")
    rec, lig, _ = jobid.split(".pdb_")

    complex_base_dir = f"{docking_dir}/complex--patchdock"
    complex_name = f"{rec}--{lig}"

    reqs = {}

    reqs['request'] = self.utility.get_file(f"{patchdock_url}/bin/zipAndDownload.pl?solutionsNum=10&id={jobid}&Submit=GO", f"{complex_base_dir}/{complex_name}/{complex_name}.submit.html")

    # Solutions ZIP
    reqs['zip_loc'] = f"{complex_base_dir}/{complex_name}/{complex_name}.topSolutions.zip"

    reqs['zip'] = self.utility.get_file(f"{patchdock_url}/runs/{jobid}/topSolutions.zip", reqs['zip_loc'])

    # Solutions File
    reqs['docking'] = self.utility.get_file(f"{patchdock_url}/runs/{jobid}/docking.res", f"{complex_base_dir}/{complex_name}/{complex_name}.docking.res")

    # Transformations
    reqs['transformations'] = self.utility.get_file(f"{patchdock_url}/runs/{jobid}/trans.txt", f"{complex_base_dir}/{complex_name}/{complex_name}.trans.txt")

    self.utility.extract_zip(reqs['zip_loc'], f"{analysis_dir}/{complex_name}")

    self.utility.copy(f"{complex_base_dir}/{complex_name}/{complex_name}.docking.res", f"{analysis_dir}/{complex_name}/{complex_name}.docking.res")

    return reqs

    """
    Use the following procedure to complete above method
    """

    # base__dir = "/mnt/DataDrive/MDD/MDA16-IL27-Modelling-SN-SOB/Drug-Peptide-Docking"
    # docking_dir = f"{base__dir}/docking"
    # analysis_dir = self.utility.validate_dir(f"{docking_dir}/analysis--patchdock")
    # log_path = f"{docking_dir}/patchdock--res--download.log.csv"

    # patchdock_email_result = f"{docking_dir}/email-result--patchdock.txt"

    # results = []
    # with open(patchdock_email_result, 'r+', encoding="utf8") as rf:
    #   results = rf.read()
    #   results = results.splitlines()

    # for res in results:
    #   reqs = download_results(res, docking_dir)
    #   self.utility.add_line_to_file(log_path, f">>>: {reqs}")

  def __generate_chimerax_commands(self, save_directory, rec_path, lig_path, file_name):
    save_directory = self.utility.validate_dir(save_directory)

    commands = [
      f"close; set bgColor white;",
      f"open {rec_path};",
      f"open {lig_path};",
      "sel #1;",
      "select sel @< 1;",
      "~sel #1;",
      "del sel;",
      "sel #2; addh;",
      "~sel;",
      "view;",
      "sel #2;",
      f"contacts #1 restrict sel radius 0.05 log t saveFile {save_directory}/{file_name}.contacts.txt;",
      f"wait;",
      f"hb #1 restrict sel reveal t show t select t radius 0.05 log t saveFile {save_directory}/{file_name}.hbonds.txt;",
      f"wait;",
      "label sel residues text {0.number}-{0.name} height 1.5 offset -2,0.25,0.25 bgColor #00000099 color white;;",
      f"save {save_directory}/{file_name}.complex.png width 1200 height 838 supersample 4 transparentBackground true;",
      f"sel #2;",
      f"view sel;",
      f"~sel;",
      f"save {save_directory}/{file_name}.ligand.png width 1200 height 838 supersample 4 transparentBackground true;",
      f"save {save_directory}/{file_name}.complex.pdb;",
    ]

    self.utility.write(f"{save_directory}/{file_name}.cxc", commands)
    return f"{save_directory}/{file_name}.cxc"

  def analyse(complex_dir, receptor_dir, ligand_dir):
    raise Exception("Not implemented yet.")
    complex_cxc_files = []
    complex_dir = str(complex_dir).rstrip("/")
    comp_dir_name = OS.path.basename(complex_dir)
    rec, lig = comp_dir_name.split("--")
    # Open Receptor PDB File in the Directory
    rec_path = f"{receptor_dir}/{rec}.pdb"
    dock_results = self.utility.find_files(complex_dir, ".pdb")
    dock_results.sort()
    # Dont Move Results to Interactions Dir in Future
    result_dir = self.utility.validate_dir(f"{complex_dir}/interactions")
    if self.utility.check_path(f"{result_dir}/{rec}--{lig}__10.complex.pdb"):
      print(f"{rec}--{lig}__10.complex.pdb Already Exist!")
      return complex_cxc_files
    for dock in dock_results:
      dock_res_name = OS.path.basename(dock)
      dock_integer = dock_res_name.split(".")[-2]
      cxc_path = self.__generate_chimerax_commands(result_dir, rec_path, dock, f"{rec}--{lig}__{dock_integer}")
      complex_cxc_files.append(f"open {cxc_path};")

    return complex_cxc_files

    """
    Use the following procedure to complete above method
    """

    # base_dir = f"{DIR__STORAGE}/MDA16-IL27-Modelling-SN-SOB/Drug-Peptide-Docking"
    # docking_dir = f"{base_dir}/docking"
    # receptor_dir = f"{docking_dir}/receptors"
    # lig_dir = f"{docking_dir}/ligands"
    # analysis_dir = f"{docking_dir}/analysis--patchdock"

    # analysis_dirs = self.utility.find_dirs(analysis_dir)

    # cxc_file_list = []

    # for comp_dir in analysis_dirs:
    #   # print(comp_dir)
    #   comp_cxc_files = generate_patchdock_chimerax_commands(comp_dir, receptor_dir, lig_dir)
    #   cxc_file_list.extend(comp_cxc_files)

    # self.utility.write(f"{docking_dir}/chimerax-commands--patchdock.cxc", cxc_file_list)