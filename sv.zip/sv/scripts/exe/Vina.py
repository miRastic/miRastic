import os as OS
from pdbtools.pdb_selaltloc import select_by_occupancy as selAltLoc

from scripts.exe.VinaBase import VinaBase

class Vina(VinaBase):
  def __init__(self, *args, **kwargs):
    super(Vina, self).__init__(*args, **kwargs)

  def prepare_receptor(self, *args, **kwargs):
    self.utility.log_info("Preparing Receptors")
    _rec_paths = self.utility.find_files(self.path_receptor, '.pdb')
    _rec_pre_paths = self.utility.find_files(self.path_receptor_pdbqt, ".pdbqt")

    if len(_rec_paths) == len(_rec_pre_paths):
      self.utility.log_warning("%i receptors already prepared. Continuing..." % len(_rec_paths))
      return

    for _rec_path in _rec_paths:
      _rec_name = self.utility.file_name(_rec_path, with_ext = True)
      if self.utility.file_name(_rec_path) in self.skipped_receptor:
        self.utility.log_warning("Receptor in Skipped List.")
        continue

      if self.utility.check_path(f"{self.path_receptor_pdbqt}{OS.sep}{_rec_name}qt"):
        self.utility.log_warning("Receptor already prepared. Delete the prepared receptor file. @TODO Force or selective override yet to be implemented.")
        continue

      # Clean PDB
      lines = []
      with open(_rec_path, 'r', encoding="utf8") as file_handle:
        lines = list(selAltLoc(file_handle))

      # @TODO: Few molecules cannot be prepared if there is record other than ATOM
      # Or use PDBParser to return standard residues only
      # protein = [str(x).rstrip("\n") for x in lines if x.startswith("ATOM")]

      _atom_records = [x for x in lines if not x.startswith("HETATM")]
      _het_records = [x for x in lines if not x.startswith("ATOM") and not x.startswith("TER")]

      _clean_receptor =  f"{self.path_receptor_clean}{OS.sep}{_rec_name}"

      self.utility.write(_clean_receptor, _atom_records)
      self.utility.log_info(f"{_rec_name} contains ATOM {len(_atom_records)} and {len(_het_records)} non-ATOM records.")

      if OS.name == 'nt':
        command = f"""ADFR is Not Implemented for windows."""
      else:
        command = f"""prepare_receptor -r "{self.path_receptor_clean}{OS.sep}{_rec_name}" -o "{self.path_receptor_pdbqt}{OS.sep}{_rec_name}qt" -A 'bonds_hydrogens' -U 'waters' -v -d "{self.path_receptor_summary}{OS.sep}{_rec_name}.summary.log" """

      # @TODO: Process Using CommandManager
      s = OS.popen(command)
      output = s.read()
      self.utility.log_info(output)
    return self

  def prepare_ligand(self, *args, **kwargs):
    # Get all the ligands with the given extension, supports pattern
    self.mol_converter.convert_molecules(self.path_ligand, self.ext_ligand, "pdb")
    _lig_paths = self.utility.find_files(self.path_ligand, ".pdb")
    _lig_pre_paths = self.utility.find_files(self.path_ligand_pdbqt, ".pdbqt")

    if len(_lig_paths) == len(_lig_pre_paths):
      self.utility.log_warning("%i ligands already prepared. Continuing..." % len(_lig_paths))
      return

    self.utility.log_info("Starting preparing %i ligands" % len(_lig_paths))

    for _lig_path in _lig_paths:
      _lig_file_name = self.utility.file_name(_lig_path)
      _lig_pdbqt_path = f"{self.path_ligand_pdbqt}{OS.sep}{_lig_file_name}.pdbqt"

      if self.utility.file_name(_lig_path) in self.skipped_ligand:
        self.utility.log_info("Ligand in Skipped List.")
        continue

      # Continue if already created
      if self.utility.check_path(_lig_pdbqt_path):
        continue

      # Directly convert pdb to pdbqt using openbabel
      _res = self.utility.cmd_run([
          "obabel", _lig_path, "-O", _lig_pdbqt_path, "-h",
          "--quiet"
        ])

      self.utility.log_info(f"Converted ligand {_lig_file_name}.\n{_res}", log_wrap = False)

    self.utility.log_info("Ligand preparation completed.")
