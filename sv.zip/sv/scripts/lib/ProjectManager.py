# TODO Fix Import

class ProjectManager():
  def __init__(self, *args, **kwargs):
    self.update_settings(*args, **kwargs)

  def update_settings(self, *args, **kwargs):
    if not hasattr(self, 'settings'): self.settings = dict()
    self.settings.update(kwargs)

    self.options = self.settings.get("ProjectManagerOptions", {
        "project__id": "002",
        "dir__upload": "/home/vishalkumarsahu/Desktop/web-upload-test",
      })

    for _i, _k in enumerate(self.options.keys()):
      if not hasattr(self, _k) or kwargs.get(_k) is not None:
        setattr(self, _k, self.settings.get(_k, self.options.get(_k)))
      if len(args) >= (_i + 1): setattr(self, _k, args[_i])

  def init(self, *args, **kwargs):
    self.update_settings(**kwargs)
    _project_dir = self.utility.validate_dir(f"{self.dir__upload}/{self.project__id}")
    return _project_dir
