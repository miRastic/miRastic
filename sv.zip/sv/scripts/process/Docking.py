from scripts.process.ProcessBase import ProcessBase

class Docking(ProcessBase):
  def __init__(self, *args, **kwargs):
    super(Docking, self).__init__(*args, **kwargs)
    self.__update_attr(*args, **kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults = {}

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def process(self, *args, **kwargs):
    kwargs["utility"] = getattr(self, "utility")
    kwargs_copied = kwargs.copy()
    self.__update_attr(**kwargs)

    if isinstance(self.path_base, (list, set, tuple)):
      for _base in self.path_base:
        kwargs_copied["path_base"] = _base
        self.vina.add(**kwargs_copied)
        self.vina.run()

    elif isinstance(self.path_base, str):
      self.vina.add(**kwargs_copied)
      self.vina.run()

    else:
      raise Exception("There was some problem accessing base path.")

  def background(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    # Process in background.
