import os as OS

import subprocess as SubProcess
import multiprocessing as MultiProcessing
from tqdm.auto import tqdm as ProgressBar

from scripts.utilitylib.TimeUtility import TimeUtility

class CommandUtility(TimeUtility):
  def __init__(self, *args, **kwargs):
    super(CommandUtility, self).__init__(**kwargs)
    self.__update_attr(**kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults =  {
        "debug": False,
        "ProgressBar": ProgressBar,
        "cpu_count": MultiProcessing.cpu_count(),
        "processes": []
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def multiprocess_start(self, *args, **kwargs):
    _processes = args[0] if len(args) > 0 else kwargs.get("processes", getattr(self, "processes"))

    # Start job in chunks
    for _batch in self.chunks(_processes, round(self.cpu_count/5)):
      for _job in _batch:
        if not _job.is_alive():
          _job.start()
      for _job in _batch:
        _job.join()
      for _job in _batch:
        # Check if job is not yet exited
        _job.terminate()

  def multiprocess_add(self, *args, **kwargs):
    _target = args[0] if len(args) > 0 else kwargs.get("target")
    _args = args[1] if len(args) > 1 else kwargs.get("args")
    _kwargs = args[2] if len(args) > 2 else kwargs.get("kwargs", {})

    _process = MultiProcessing.Process(target=_target, args=_args, kwargs=_kwargs, daemon=True)
    self.processes.append(_process)
    return _process

  def cmd_is_exe(self, fpath):
    return OS.path.isfile(fpath) and OS.access(fpath, OS.X_OK)

  def cmd_which(self, program):
    fpath, fname = OS.path.split(program)
    if fpath:
      if self.is_exe(program):
        return program
    else:
      for path in OS.environ["PATH"].split(OS.pathsep):
        path = path.strip('"')
        exe_file = OS.path.join(path, program)
        if self.is_exe(exe_file):
          return exe_file
    return None

  def cmd_call(self, *args, **kwargs):
    _command = args[0] if len(args) > 0 else kwargs.get("command")

    if isinstance(_command, str):
      _command = _command.split()

    process = SubProcess.call(_command, shell=True)
    return process

  def cmd_run(self, *args, **kwargs):
    _command = args[0] if len(args) > 0 else kwargs.get("command")
    _newlines = args[1] if len(args) > 1 else kwargs.get("newlines", True)

    if _command is None:
      return None

    if isinstance(_command, str):
      _command = _command.split(" ")

    _output = None

    _process = SubProcess.Popen(_command, stdout=SubProcess.PIPE, universal_newlines=_newlines)
    _output, _error = _process.communicate()

    return _output
