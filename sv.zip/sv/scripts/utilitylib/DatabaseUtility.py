import sqlite3 as SQLite3
from sqlalchemy import create_engine
import pandas as PD

from scripts.utilitylib.CommandUtility import CommandUtility

class DatabaseUtility(CommandUtility):
  app_name = "Scrapper"
  sqlite = SQLite3
  engine = None
  db_path = None
  is_connected = False

  def __init__(self, *args, **kwargs):
    super(DatabaseUtility, self).__init__(**kwargs)
    self.__update_attr(**kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults =  {
        "debug": True,
        "db_path": "scrapper.db",
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

    if getattr(self, "debug", False):
      print(f"Connecting {self.db_path}...")
      raise Exception

  def __init_sqlite_engine(self, *args, **kwargs):
    self.db_path = args[0] if len(args) > 0 else kwargs.get("db_path", getattr(self, "db_path"))

    if self.is_connected:
      return self.db_path

    if len(self.db_path) > 3:
      self.engine = create_engine(f"sqlite:////{self.db_path}", echo = self.debug)
      self.is_connected = True
      return self.db_path
    else:
      raise Exception("Failed to connect to SQLite DB.")

  def db_connect(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    if not kwargs.get("username") or not kwargs.get("db_name"):
      return self.__init_sqlite_engine(*args, **kwargs)
    # else:
      # Connect to MySQL Database

  # Accessory functions using pandas

  def set_table_data(self, *args, **kwargs):
    _data_entries = args[0] if len(args) > 0 else kwargs.get("data")
    _table = args[1] if len(args) > 1 else kwargs.get("table_name")
    _if_exists = args[2] if len(args) > 2 else kwargs.get("if_exists", "append")
    _db_engine = args[3] if len(args) > 3 else kwargs.get("engine", self.engine)
    _chunk_size = args[4] if len(args) > 4 else kwargs.get("chunk_size", 50)
    _method = args[5] if len(args) > 5 else kwargs.get("method", 'multi')
    _index = args[6] if len(args) > 6 else kwargs.get("index", False)

    if isinstance(_data_entries, PD.DataFrame):
      return _data_entries.to_sql(_table, _db_engine, if_exists=_if_exists, chunksize = _chunk_size, method = _method, index = _index)
    else:
      raise Exception("[Error] Requires dataframe. Got some other data type.")

  def get_last_id(self, *args, **kwargs):
    _table = args[0] if len(args) > 0 else kwargs.get("table_name")
    _id_column = args[1] if len(args) > 1 else kwargs.get("id_column")
    _db_engine = args[2] if len(args) > 2 else kwargs.get("engine", self.engine)
    _db_id = args[3] if len(args) > 3 else kwargs.get("default", 0)
    try:
      if all([_table, _id_column]):
        _res = PD.read_sql(f"SELECT * FROM {_table} ORDER BY {_id_column} DESC LIMIT 1;", _db_engine)
        _res[_id_column] = _res[_id_column].astype(int)
        if len(_res.index) != 0:
          _db_id = int(_res[_id_column].values[0])
    except:
      self.log_error(f"Error in get_last_id for {_table}.")

    return _db_id

  def __correct_table_type(self, *args, **kwargs):
    _data = args[0] if len(args) > 0 else kwargs.get("data")
    _column_details = args[1] if len(args) > 1 else kwargs.get("column_details")

    if all([isinstance(_data, PD.DataFrame), _column_details, isinstance(_column_details, dict)]):
      for _key, _type in _column_details.items():
        _data[_key] = _data[_key].astype(_type)

    return _data

  def __empty_table_with_columns(self, *args, **kwargs):
    _column_details = args[0] if len(args) > 0 else kwargs.get("column_details")
    if _column_details is not None and isinstance(_column_details, dict):
      _columns = list(_column_details.keys())
      return PD.DataFrame(columns=_columns)
    return None

  def get_table_data(self, *args, **kwargs):
    _table = args[0] if len(args) > 0 else kwargs.get("table_name")
    _where = args[1] if len(args) > 1 else kwargs.get("where")
    _db_engine = args[2] if len(args) > 2 else kwargs.get("engine", self.engine)

    _db_entries = self.__empty_table_with_columns(**kwargs)

    if _table is None:
      return _db_entries

    try:
      if _where and isinstance(_where, dict):
        _where_clause = ""
        for _key in _where.keys():
          if _where[_key] is not None:
            if len(_where_clause) > 5:
              _where_clause = f" {_where_clause} AND "

            _where_val_connector = "=" if isinstance(_where[_key], str) else "IN"
            _where_values = repr(_where[_key]) if isinstance(_where[_key], str) else f"({', '.join(map(repr, _where[_key]))})"
            _where_clause = f"{_where_clause}{_key} {_where_val_connector} {_where_values}"

        _db_entries = PD.read_sql(f"SELECT * FROM {_table} WHERE {_where_clause}", _db_engine)
      else:
        _db_entries = PD.read_sql_table(_table, _db_engine)
    except:
      self.log_info(f"Some error occurred while accessing table '{_table}'.")

    _db_entries = self.__correct_table_type(_db_entries, **kwargs)
    return _db_entries
