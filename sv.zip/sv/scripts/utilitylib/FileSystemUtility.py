import os as OS
import re as REGEX

from warnings import warn as WARN

import requests as REQUESTS
import shutil as SHUTIL
from zipfile import ZipFile
from pathlib import Path as PATH
import urllib as URL
from glob import glob as GLOB

import json as JSON
import ast as AbsSynTree
import csv as CSV
import xmltodict as XMLTODICT
from lxml import etree as XMLTree

from scripts.utilitylib.LoggingUtility import LoggingUtility

class FileSystemUtility(LoggingUtility):
  def __init__(self, *args, **kwargs):
    super(FileSystemUtility, self).__init__(**kwargs)
    self.__update_attr(**kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults =  {
        "debug": False,
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def read_xml(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _source = args[0] if len(args) > 0 else kwargs.get("source")
    _content = ""
    if self.check_path(_source):
      _tree = XMLTree.parse(_source)
      _content = _tree.getroot()
    _content = self.xml_to_dict(_content)
    return _content

  def read_text(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _file_path = args[0] if len(args) > 0 else kwargs.get("file_path")
    _content = None
    with open(_file_path, 'r', encoding='UTF8') as f:
      _content = f.readlines()
    return _content

  def read_json(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _file_path = args[0] if len(args) > 0 else kwargs.get("file_path")
    _res_dict = {}

    if self.check_path(_file_path):
      _content = self.read_text(_file_path)
      _content = "".join(_content)
      try:
        _res_dict = JSON.loads(_content)
      except:
        _res_dict = AbsSynTree.literal_eval(_content)

    return _res_dict

  def write(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _destination = args[0] if len(args) > 0 else kwargs.get("destination")
    _content = args[1] if len(args) > 1 else kwargs.get("content", "")
    _append = args[2] if len(args) > 2 else kwargs.get("append", False)
    _encoding = args[3] if len(args) > 3 else kwargs.get("encoding", "utf-8")
    _mode = args[4] if len(args) > 4 else kwargs.get("mode", "w+")
    _position = args[5] if len(args) > 5 else kwargs.get("position", 0)

    if _append is True:
      # Change any mode to a
      _mode = _mode[:0] + 'a' + _mode[1:]

    # Create dir if doesn't exist
    if OS.path.isdir(_destination):
      raise Exception(f"{_destination} already exists as a directory. Cannot write as a file.")

    _parent_path = self.validate_dir(OS.path.dirname(_destination))
    _file_name = self.filename(_destination, True)
    self.log_info(f"Writing {_file_name} to {_parent_path}.")

    with open(_destination, _mode, encoding = _encoding) as _fh:
      if _mode.startswith("w"):
        _fh.seek(_position)

      if isinstance(_content, str):
        _fh.write(_content)
      elif isinstance(_content, (list, tuple, set)):
        _fh.write("\n".join(_content))

    return self.check_path(_destination)

  def write_json(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _destination = args[0] if len(args) > 0 else kwargs.get("destination")
    _content = args[1] if len(args) > 1 else kwargs.get("content", dict())
    if isinstance(_content, dict):
      _json_data = JSON.dumps(_content, ensure_ascii=False)
      self.write(_destination, _json_data)
    return self.check_path(_destination)

  def write_xml(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _destination = args[0] if len(args) > 0 else kwargs.get("destination")
    _content = args[1] if len(args) > 1 else kwargs.get("content")
    self.write(_destination, _content, **kwargs)
    return self.check_path(_destination)

  def conv_xml_to_dict(self, *args, **kwargs):
    WARN("@deprecated, instead use xml_to_dict.")
    return self.xml_to_dict(*args, **kwargs)

  def xml_to_dict(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _data = args[0] if len(args) > 0 else kwargs.get("data")
    _res = {}
    try:
      if not isinstance(_data, (str)):
        _data = XMLTree.tostring(_data, encoding='utf8', method='xml')
      _res = XMLTODICT.parse(_data)
    except:
      self.log_info(f"Failed to convert XML to DICT. Some error occurred.")
    return _res

  def dict_to_csv(self, *args, **kwargs):
    _destination = args[0] if len(args) > 0 else kwargs.get("destination")
    _data = args[1] if len(args) > 1 else kwargs.get("data")

    if isinstance(_data, list) and isinstance(_data[0], dict):
      _keys = _data[0].keys()
      with open(_destination, 'w+', newline='', encoding="utf8") as _ofh:
        _dict_writer = CSV.DictWriter(_ofh, _keys)
        _dict_writer.writeheader()
        _dict_writer.writerows(_data)
    return self.check_path(_destination)

  def copy(self, *args, **kwargs):
    _source = args[0] if len(args) > 0 else kwargs.get("source")
    _destination = args[1] if len(args) > 1 else kwargs.get("destination")

    if not all([_source, _destination]):
      self.log_info(f"Source or Destination is not specified.")
      return False

    self.validate_dir(OS.path.dirname(_destination))

    self.log_info(f"Copying... {_source} to {_destination}.")
    SHUTIL.copyfile(_source, _destination)

  def extract_zip(self, *args, **kwargs):
    _source = args[0] if len(args) > 0 else kwargs.get("source")
    _destination = args[1] if len(args) > 1 else kwargs.get("destination")

    self.validate_dir(_destination)

    if self.check_path(_source):
      SHUTIL.unpack_archive(_source, _destination)
      self.log_info(f"Extracted {_source} content in {_destination}.")
      return True

      # Extracts ZIP Files Only
      # with ZipFile(str(_source), 'r') as zipObj:
      #   zipObj.extractall(des_dir)

    return self.check_path(_destination)

  def delete_path(self, *args, **kwargs):
    _path = args[0] if len(args) > 0 else kwargs.get("path")

    if not self.check_path(_path):
      return True
    if OS.path.isfile(_path):
      OS.remove(_path)
    elif OS.path.isdir(_path):
      SHUTIL.rmtree(_path)

    return self.check_path(_path)

  def get_file(self, *args, **kwargs):
    _url = args[0] if len(args) > 0 else kwargs.get("url")
    _destination = args[1] if len(args) > 1 else kwargs.get("destination", None)
    _return_text = args[2] if len(args) > 2 else kwargs.get("return_text", False)
    _overwrite = args[3] if len(args) > 3 else kwargs.get("overwrite", False)
    _form_values = args[4] if len(args) > 4 else kwargs.get("form_values", None)
    _headers = args[5] if len(args) > 5 else kwargs.get("headers", {})

    _default_headers = {'User-agent': 'Mozilla/5.0'}
    _default_headers.update(_headers)

    if not _overwrite and self.check_path(_destination):
      self.log_warning(f"{_url} exists at {_destination}.")
      return None

    if not _destination:
      # Return text if writing destination not provided
      _return_text = True

    try:
      session = REQUESTS.Session()
      session.headers.update(_default_headers)
      self.log_info(f"Downloading content from {_url}.")
      _response = session.get(_url, stream=True, data=_form_values)
      if _destination:
        kwargs.pop("content", None)
        kwargs.pop("destination", None)
        self.write(_destination, _response.content, **kwargs)
      if _return_text:
        return _response.text
    except:
      self.log_warning(f"Normal procedure failed. Trying alternate method 'urlretrieve'.")
      URL.request.urlretrieve(_url, _destination)

    return self.check_path(_destination)

  def find_dirs(self, *args, **kwargs):
    return self.search_dirs(*args, **kwargs)

  def search_dirs(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _source = args[0] if len(args) > 0 else kwargs.get("dir", getattr(self, "dir"))
    _pattern = args[1] if len(args) > 1 else kwargs.get("pattern", "/*/")
    return self.search(_source, _pattern)

  def find_files(self, *args, **kwargs):
    return self.search_files(*args, **kwargs)

  def search_files(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _source = args[0] if len(args) > 0 else kwargs.get("dir", getattr(self, "dir"))
    _pattern = args[1] if len(args) > 1 else kwargs.get("pattern", "*")

    if not isinstance(_pattern, (list, set, tuple)):
      _pattern = f"*{_pattern}"

    return self.search(_source, _pattern)

  def search(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _results = []
    _source = args[0] if len(args) > 0 else kwargs.get("source", getattr(self, "source"))
    _pattern = args[1] if len(args) > 1 else kwargs.get("pattern")

    if not _source or not _pattern:
      return _results

    if isinstance(_pattern, (list, set, tuple)):
      for _p in _pattern:
        _results.extend([str(f) for f in PATH(_source).glob(_p)])

    elif isinstance(_pattern, str):
      _results = [str(f) for f in PATH(_source).glob(_pattern)]

    elif isinstance(_pattern, dict):
      _pattern = list(_pattern.items())
      for _p in _pattern:
        _results.extend([str(f) for f in PATH(_source).glob(_p)])
    else:
      raise Exception("Unsupported pattern type provided.")

    return _results

  def create_dir(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _dir_paths = args[0] if len(args) > 0 else kwargs.get("dirs")

    if isinstance(_dir_paths, str):
      _dir_paths = [_dir_paths]

    _dir_created = {}
    for _d in _dir_paths:
      if not OS.path.exists(_d):
        self.log_info(f"Path does not exist. Creating {_d}...")
        _res = OS.makedirs(_d)
        _dir_created[_d] = _res

    return _dir_created

  def check_path(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _path = args[0] if len(args) > 0 else kwargs.get("path")

    if not _path:
      return None

    return OS.path.exists(_path)

  def validate_subdir(self, *args, **kwargs):
    _base = args[0] if len(args) > 0 else kwargs.get("base")
    _sub = args[0] if len(args) > 0 else kwargs.get("sub")
    r = REGEX.compile(r"[/\\]")
    # Check if sub_dir contains any slash so that it is not directory name, append it's parent path
    if r.search(str(_sub)) == None:
      return self.validate_dir(f"{_base}{OS.sep}{_sub}")
    else:
      return self.validate_dir(_sub)

  def validate_dir(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _dir = args[0] if len(args) > 0 else kwargs.get("dir")
    if not self.check_path(_dir):
      _res = self.create_dir(_dir, **kwargs)
      if _dir in _res.keys():
        self.log_info(f"Directory created.")
      else:
        self.log_info(f"Failed to create directory {_dir}.")
    return _dir

  def change_ext(self, *args, **kwargs):
    _fp = args[0] if len(args) > 0 else kwargs.get("file")
    _to = args[1] if len(args) > 1 else kwargs.get("to")
    _from = args[2] if len(args) > 2 else kwargs.get("from")
    _num_ext = args[3] if len(args) > 3 else kwargs.get("num_ext", 1)

    _current_ext = self.ext(_fp, _num_ext)

    if _from is not None:
      if _current_ext == _from:
        _f_wo_ext = self.file_name(_fp, with_dir = True, num_ext = _num_ext)
      else:
        WARN("From and Current extensions are not same.")
        return _fp
    else:
      _f_wo_ext = self.file_name(_fp, with_dir = True, num_ext = _num_ext)

    return ".".join((_f_wo_ext, _to))

  def file_dir(self, *args, **kwargs):
    """
    Returns parent directory path from the input
    """
    _fpath = args[0] if len(args) >= 1 else kwargs.get("path")
    _validate = args[1] if len(args) >= 2 else kwargs.get("validate", False)
    if _fpath:
      _fpath = OS.path.dirname(_fpath)

    if _validate and not OS.path.isdir(_fpath):
      return None

    return _fpath

  def file_name(self, *args, **kwargs):
    return self.filename(*args, **kwargs)

  def filename(self, *args, **kwargs):
    """ Returns file_name from path /<path>/<file_name>.<ext1>.<ext2> """
    _file_path = args[0] if len(args) > 0 else kwargs.get("file_path")
    _with_ext = args[1] if len(args) > 1 else kwargs.get("with_ext", False)
    _with_dir = args[2] if len(args) > 2 else kwargs.get("with_dir", False)
    _num_ext = args[3] if len(args) > 3 else kwargs.get("num_ext", 1)

    if not _file_path:
      return None

    if _with_dir is False:
      _file_path = OS.path.basename(_file_path)

    if _with_ext is True:
      return str(_file_path)

    _file_path = _file_path.rsplit(".", _num_ext)

    if len(_file_path):
      return _file_path[0]

    return None

  def file_ext(self, *args, **kwargs):
    return self.ext(*args, **kwargs)

  def ext(self, *args, **kwargs):
    """ Returns File Extension """
    _file_path = args[0] if len(args) > 0 else kwargs.get("file_path")
    _num_ext = args[1] if len(args) > 1 else kwargs.get("num_ext", 1)
    _delimiter = args[2] if len(args) > 2 else kwargs.get("delimiter", ".")

    _file_path = OS.path.basename(_file_path)
    _file_path = _file_path.rsplit(_delimiter, _num_ext)
    _file_path = f"{_delimiter}".join(_file_path[-_num_ext:])
    return _file_path

  def split_file(self, *args, **kwargs):
    # TODO
    _file_path = args[0] if len(args) > 0 else kwargs.get("file_path")
    _sdf_id_delimiter = args[2] if len(args) > 2 else kwargs.get("id_delimiter")
