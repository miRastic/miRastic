import pandas as PD
import textwrap as TextWrapper

from scripts.utilitylib.DatabaseUtility import DatabaseUtility

class LoggingUtility(DatabaseUtility):
  def __init__(self, *args, **kwargs):
    super(LoggingUtility, self).__init__(**kwargs)
    self.__fg = lambda text, color: "\33[38;5;" + str(color) + "m" + text + "\33[0m"
    self.__bg = lambda text, color: "\33[48;5;" + str(color) + "m" + text + "\33[0m"

    self.__update_attr(**kwargs)

  def __update_attr(self, *args, **kwargs):
    _default_colors = {
        "blue": 4,
        "green": 2,
        "white": 255,
        "orange": 202,
        "red": 1,
      }

    _default_status = {
        "ok": self.__bg("[SUCCESS]", _default_colors['green']),
        "debug": self.__bg("[DEBUG]", _default_colors['blue']),
        "info": self.__bg("[INFO]", _default_colors['blue']),
        "fail": self.__bg("[FAIL]", _default_colors['red']),
        "error": self.__bg("[ERROR]", _default_colors['red']),
        "warning": self.__bg("[WARNING]", _default_colors['orange']),
      }

    if not hasattr(self, "__defaults"): self.__defaults = {
        "log_print": 0,
        "type": "info",
        "log_file_name": "app-process.log",
        "log_table_name": "db_watchdog",
        "colors": _default_colors,
        "status": _default_status,
        "step": False,
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def __log(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _wrap_message = kwargs.get("log_wrap", True)
    _db_log = []

    for _message in args:
      _print_msg = f"{self.status[self.type]} [{self.time_elapsed()}] {str(_message)}"
      if _wrap_message:
        _print_msg = TextWrapper.fill(_print_msg, width=80, subsequent_indent = " " * int(len(self.status[self.type])/2 - 2))

      print(_print_msg, flush=True)
      # print("\033[H\033[J", end="") # Clears output of the console

      _db_log.append({
        "type": self.type,
        "message": str(_message),
        "time": self.time_get()
      })

      if getattr(self, 'step_pause', False):
        input("Step_Pause Enabled. Press enter to continue...")
        self.__update_attr(step = False)

    _db_log_df = PD.DataFrame(_db_log)

    if getattr(self, 'engine'):
      _db_log_df.to_sql(self.log_table_name, self.engine, if_exists='append', index = False)
    else:
      _db_log_df.to_csv(self.log_file_name, mode='a', header=False)

  def log_info(self, *args, **kwargs):
    self.__update_attr(type="info")
    return self.__log(*args, **kwargs)

  def log_debug(self, *args, **kwargs):
    self.__update_attr(type="debug")
    return self.__log(*args, **kwargs)

  def log_warning(self, *args, **kwargs):
    self.__update_attr(type="warning")
    return self.__log(*args, **kwargs)

  def log_error(self, *args, **kwargs):
    self.__update_attr(type="error")
    return self.__log(*args, **kwargs)

  def log_success(self, *args, **kwargs):
    self.__update_attr(type="success")
    return self.__log(*args, **kwargs)

  def log_fail(self, *args, **kwargs):
    self.__update_attr(type="fail")
    return self.__log(*args, **kwargs)
