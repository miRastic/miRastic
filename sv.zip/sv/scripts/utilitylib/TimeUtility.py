import time as TIME
import datetime as DATETIME

class TimeUtility():
  def __init__(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    self.time_start()

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, '__defaults'): self.__defaults = {
        "debug": False,
        "duration": 2,
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def time_get(self):
    self.pinned_time = TIME.time()
    return self.pinned_time

  def time_to_string(self, *args, **kwargs):
    # https://stackoverflow.com/a/10981895/6213452
    _time = args[0] if len(args) > 0 else kwargs.get("time")

    # days = td.days
    # hours, remainder = divmod(td.seconds, 3600)
    # minutes, seconds = divmod(remainder, 60)
    # # If you want to take into account fractions of a second
    # seconds += td.microseconds / 1e6

    if _time:
      return _time

  def time_elapsed(self, *args, **kwargs):
    _from = args[0] if len(args) > 0 else kwargs.get("from", self.time_get())
    _human_readable = args[1] if len(args) > 1 else kwargs.get("human_readable", False)
    _seconds_elapsed = _from - self.start_time
    _time_delta = DATETIME.timedelta(seconds=_seconds_elapsed)
    _res_time = str(_time_delta)

    if _human_readable:
      _res_time = self.time_to_string(_time_delta)

    return _res_time

  def time_start(self, *args, **kwargs):
    self.start_time = self.time_get()
    self.pinned_time = self.time_get()
    return self.start_time

  def time_end(self, *args, **kwargs):
    return self.time_get() - self.start_time

  def time_sleep(self, *args, **kwargs):
    return self.time_pause(*args, **kwargs)

  def time_pause(self, *args, **kwargs):
    self.__update_attr(**kwargs)
    _duration = args[0] if len(args) > 0 else kwargs.get("duration", getattr(self, "duration"))
    TIME.sleep(_duration)
