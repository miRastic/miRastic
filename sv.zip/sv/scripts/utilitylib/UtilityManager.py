import itertools as ITERTOOLS

from scripts.utilitylib.FileSystemUtility import FileSystemUtility

class UtilityManager(FileSystemUtility):
  def __init__(self, *args, **kwargs):
    super(UtilityManager, self).__init__(**kwargs)
    self.__update_attr(*args, **kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, '__defaults'): self.__defaults = {}

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def chunks(self, *args, **kwargs):
    _list = args[0] if len(args) > 0 else kwargs.get("list")
    _size = args[1] if len(args) > 1 else kwargs.get("size", 4)
    for _n in range(0, len(_list), _size):
      yield _list[_n:_n+_size]

  def combination(self, *args, **kwargs):
    _list1 = args[0] if len(args) > 0 else kwargs.get("list1")
    _list2 = args[1] if len(args) > 1 else kwargs.get("list2")
    return list(ITERTOOLS.product(_list1, _list2))
