from scripts.web.WebBase import WebBase

class Page(WebBase):
  app = None
  content_map = {
      "js/main.js": {
        "type": 'assets',
        "title": "js",
        "filepath": "js/main.js"
      },
      "css/style.css": {
        "type": 'assets',
        "title": "css",
        "filepath": "css/style.css"
      },
      "dock": {
        "type": 'content',
        "title": "Sieve-AI Docking",
        "menu": "main_menu",
        "page__template": "app/docking-form.html.twig",
      },
      "docking-help": {
        "type": 'content',
        "title": "Docking Help",
        "menu": "main_menu",
        "page__template": "app/docking-form.html.twig",
      },
      "about": {
        "type": 'content',
        "title": "About Sieve-AI",
        "menu": "main_menu",
        "page__template": "static/about.html",
      },
      "home": {
        "type": 'content',
        "title": "Welcome to Sieve-AI",
        "menu": "main_menu",
        "page__template": "static/home.html",
      },
    }

  def __init__(self, *args, **kwargs):
    super(Page, self).__init__(**kwargs)
    self.__update_attr(*args, **kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults =  {
        "path_base": None,
        "dir_receptor": None,
        "dir_ligand": None
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def __process_post_data(self, *args, **kwargs):
    _path = args[0] if len(args) > 0 else kwargs.get("path", "")
    if _path:
      for _n in self.request.files:
        _f = self.request.files.get(_n)
        if _f.filename != '':
          _fn = self.secure_filename(_f.filename)
          _dn = self.secure_filename(_n)
          _entity_dir = self.file_manager.validate_dir(f"{self.path_project}/{_dn}")
          _f.save(f"{_entity_dir}/{_fn}")
    else:
      return self.redirect(self.request.url, code=302)
    from scripts.process.Docking import Docking
    Docking(**{"path_base": self.path_project,
               "dir_receptor": 'receptor',
               "dir_ligand": 'ligand'})

  def __render_json(self, *args, **kwargs):
    res = self.jsonify()
    return res

  def __path_key(self, *args, **kwargs):
    _path = args[0] if len(args) > 0 else kwargs.get("path", "")
    _key = _path
    return _key    

  def __path_mapping(self, *args, **kwargs):
    _path = args[0] if len(args) > 0 else kwargs.get("path", "")
    self.page__variables["message"] = _path
    _path_key = self.__path_key(_path)

    self.page__variables["message"] = self.content_map.get(_path_key)

    return self.content_map.get(_path_key, {
      "type": "content",
      "title": _path_key,
      "message": _path_key,
      "page__template": "common/index.html.twig",
    })

  def __set_menus(self, *args, **kwargs):
    # for c in self.content_map:
    #   print(self.content_map[c])
    _main_menu = {c: self.content_map[c] for c in self.content_map if self.content_map[c].get("menu") == "main_menu"}
    self.page__variables["main_menu"] = _main_menu

  def __render_template(self, *args, **kwargs):
    _path = kwargs.get('path', 'home')
    _values = self.__path_mapping(_path)

    self.__set_menus(**kwargs)
    
    self.page__variables.update(_values)

    if self.request.method == "POST":
      self.page__variables["message"] = self.__process_post_data(path=_path)

    if _values.get("type") == "assets":
      print(_path)
      return self.send_from_dir("assets", _path)

    return self.view("page.html.twig", **self.page__variables)

  def init(self, *args, **kwargs):
    kwargs["methods"] = kwargs.get("methods", ["GET", "POST"])

    # Register HomePage Endpoint
    self.add_endpoint(endpoint=f"/", endpoint_name=f"home", handler=self.__render_template, **kwargs)

    # Register All other Paths
    for _key in ["<path:path>"]:
      self.add_endpoint(endpoint=f"/{_key}", endpoint_name=f"{_key}", handler=self.__render_template, **kwargs)

  def live(self, *args, **kwargs):
    self.init(*args, **kwargs)
    self.run(*args, **kwargs)

  def dev(self, *args, **kwargs):
    self.init(*args, **kwargs)
    self.run(*args, **kwargs)
