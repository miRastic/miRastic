import os as OS
from flask import Flask, Response, redirect as Redirect
from flask import render_template as FlaskViewBuilder, request as Request
from flask import jsonify as JSONIFY
from flask import send_from_directory as Send_From_Directory
from werkzeug.utils import secure_filename as SecureFileName

from scripts.lib.FileManager import FileManager
from scripts.lib.ProjectManager import ProjectManager

class WebBase(object):
  app = None
  def __init__(self, *args, **kwargs):
    self.__update_attr(*args, **kwargs)
    self.page__variables["page__template"] = "common/index.html.twig"
    self.app = Flask(self.app_name, template_folder = self.path_template, static_folder = self.path_static, static_url_path="/assets")
    self.app.config['UPLOAD_FOLDER'] = self.path_upload

    # Setup Project directory and db
    # if self.app is not None:
    #   self.path_project = self.project_manager.init(*args, **kwargs)

  def __update_attr(self, *args, **kwargs):
    if not hasattr(self, "__defaults"): self.__defaults =  {
        "app_name": "Sieve-AI",
        "host": "10.20.18.59",
        "port": "4110",
        "debug": True,
        "threaded": True,
        "path_upload": OS.path.expanduser("~/Desktop/sieve-ai-project"),
        "path_project": OS.path.expanduser("~/Desktop/sieve-ai-project/saiv1-p001"),
        "allowed__extensions": {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'},
        "path_static": OS.path.normpath(OS.path.join(__file__, "../../../assets")),
        "path_template": OS.path.normpath(OS.path.join(__file__, "../../../assets/templates")),
        "view": FlaskViewBuilder,
        "response": Response,
        "page__variables": {},
        "jsonify": JSONIFY,
        "send_from_dir": Send_From_Directory,
        "request": Request,
        "redirect": Redirect,
        "secure_filename": SecureFileName,
        "file_manager": FileManager(**kwargs),
        "project_manager": ProjectManager(**kwargs),
      }

    # Set all defaults
    [setattr(self, _k, self.__defaults[_k]) for _k in self.__defaults.keys() if not hasattr(self, _k)]
    self.__defaults = dict() # Unset defaults to prevent running for second time
    [setattr(self, _k, kwargs[_k]) for _k in kwargs.keys()]

  def add_endpoint(self, *args, **kwargs):
    # https://stackoverflow.com/a/40466535/16963281
    # a.add_endpoint(endpoint='/ad', endpoint_name='ad', handler=action)
    _endpoint = args[0] if len(args) > 0 else kwargs.get("endpoint")
    _endpoint_name = args[1] if len(args) > 1 else kwargs.get("endpoint_name")
    _handler = args[2] if len(args) > 2 else kwargs.get("handler")
    _methods = args[3] if len(args) > 3 else kwargs.get("methods", ["get"])
    
    self.app.add_url_rule(_endpoint, _endpoint_name, _handler, methods = _methods, defaults=kwargs)

  def _serve(self, *args, **kwargs):
    return self.view("page.html.twig", **self.page__variables)

  def run(self, *args, **kwargs):
    self.app.run(host = self.host, port = self.port, debug = self.debug, threaded = self.threaded)

  def live(self, *args, **kwargs):
    self.run(*args, **kwargs)

  def dev(self, *args, **kwargs):
    self.run(*args, **kwargs)
